<!-- navbar --> 
      <nav class="navbar navbar-expand-md navbar-dark bg-dark ">
      <a class="navbar-brand" href="index.php" style="color : 	pale yellow;"><b>SPARKS BANK</b></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color : #daa520;"><b>Home</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transfermoney.php" style="color : #daa520;"><b>Money Remittance </b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="history.php" style="color : #daa520;"><b>Transaction History</b></a>
              </li>
          </div>
       </nav>
